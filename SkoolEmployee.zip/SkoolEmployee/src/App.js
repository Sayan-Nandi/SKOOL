import React, { Component } from 'react';
import './App.css';
import Text from './Components/Controls/Text';
import axios from 'axios';


class App extends Component {
  constructor(props){
    super(props);
    this.state = {
      idEmployee: 0,
      text: [],

    }
  }
  componentWillMount(){
    this.getSampleText();
      
      
  }
    
      

  getSampleText(){
    axios.get('https://h8cecj40pk.execute-api.us-west-1.amazonaws.com/dev/GetEmployeeDetailsByTeam?TeamId='+this.state.idEmployee)
      .then((response) => {
        this.setState({text: response.data[0]}, function(){
        console.log(this.state.text);
        });
        console.log(response);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  showHtml(x){
      this.setState({html: x}, this.getSampleText);
  }

  changeParas(number){
      this.setState({idEmployee: number}, this.getSampleText);
  }

  render() {



    return this.state.text ? (
        <div id="page-wrapper">
        <div className="App container">
        <h1 className="text-center">Employee List</h1>
        <hr />
        <form className="form-inline">
        <div className="form-group">
            <label>Team</label> 
        <Text value={this.state.paras} onChange={this.changeParas.bind(this)} />
        </div>

        </form>
        <br /><br />
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                </div>
                                <div class="panel-body">
    <table width="100%" class="table table-striped table-bordered table-hover" id="example">
      <thead>
        <tr>
          <th>EmpId</th>
          <th>Name</th>
          <th>ISD Information</th>
          <th>LN Id</th>
          <th>IBM Doj</th>
          <th>Account Doj</th>
          <th>Team Name</th>
          <th>Overall Score</th>
        </tr>
      </thead>
      <tbody>
        {
          this.state.text.map(function (employee) {
            return (<tr key={employee.EmployeeId} class="gradeA">
              <td className="center">{employee.EmployeeId}</td>
              <td className="center">{employee.Employeename}</td>
              <td className="center">{employee.EmployeeISDInformation}</td>
              <td className="center">{employee.EmployeeLNid}</td>
              <td className="center">{employee.EmployeeIBMDOJ}</td>
              <td className="center">{employee.EmployeeAccDOJ}</td>
              <td className="center">{employee.TeamName}</td>
              <td className="center">{employee.EmployeeTeamOverAllScore}</td>
            </tr>
          )})
        }
      </tbody>
          </table>
          </div>
          </div>
          </div>
          </div>
          </div>
          </div>
    ): 
    <div className="App container">
        <h1 className="text-center">Employee List</h1>
        <hr />
        <form className="form-inline">
          <div className="form-group">
            <label>Search:</label>
            <Text value={this.state.paras} onChange={this.changeParas.bind(this)} />
          </div>
        </form>
        <br /><br />
        <div className="row">
       <div className="col-lg-12">
         <div className="panel panel-default">
           <div className="panel-heading">
           DataTables Advanced Tables
           </div>    
    <table className="table table-striped table-bordered table-hover" style={{ display: "inline-table" }}>
      <thead>
        <tr>
          <th>EmpId</th>
          <th>Name</th>
          <th>ISD Information</th>
          <th>LN Id</th>
          <th>IBM Doj</th>
          <th>Account Doj</th>
          <th>Team Name</th>
          <th>Overall Score</th>
        </tr>
      </thead>
      <tbody>
        {

        }
      </tbody>
    </table>
  </div>
 </div>
</div>
</div>;
  }
}

export default App;
