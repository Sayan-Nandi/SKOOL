import React, {Component} from 'react';
import axios from 'axios';

class Select extends Component{
  constructor(props){
    super(props);
    this.state = {
        userid: 0,
        value: []
    }
  }
  
  getSampleText(){
    axios.get('https://h8cecj40pk.execute-api.us-west-1.amazonaws.com/dev/GetEmployeeDetailsByTeam?TeamId='+this.state.idEmployee)
      .then((response) => {
        this.setState({text: response.data[0]}, function(){
        console.log(this.state.text);
        });
        console.log(response);
      })
      .catch((err) => {
        console.log(err);
      });
  }
  
    
    
  onChange(e){
      axios.get('https://h8cecj40pk.execute-api.us-west-1.amazonaws.com/dev/teams?userid='+this.state.userid)
      .then((response) => {
    this.setState({value: e.target.value}, function(){
        alert(this.state.value);
      this.props.onChange(this.state.value);
    });
  }).catch((err) => {
        console.log(err);
      });
  }
  
    
  render(){
      
    return (
      <div id="wrapper1">
        <select id="Sleect" className="form-control" onChange={this.onChange.bind(this)}>
          <option value="true">Yes</option>
          <option value="false">No</option>
        </select>
      </div>
    )
  }
}

export default Select;